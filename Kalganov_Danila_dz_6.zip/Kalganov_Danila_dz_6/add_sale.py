import sys


def write_sale(num):
    with open('bakery.csv', 'a', encoding='utf-8') as f:
        f.write(f'{num}\n')


amount = sys.argv[1]
write_sale(amount)
