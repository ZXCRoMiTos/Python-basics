from requests import get

with open('nginx_logs.txt', 'w', encoding='utf-8') as f:
    response = get("https://github.com/elastic/examples/raw/master/Common%20Data%20Formats/nginx_logs/nginx_logs")
    content = response.content.decode(encoding=response.encoding)
    f.write(content)

result = []
spamming_ip = {}

with open('../nginx_logs.txt', 'r', encoding='utf-8') as f:
    for line in f:
        remote_address = line.split()[0]
        request_type = line.split()[5].replace('"', '')
        requested_resource = line.split()[6]
        result.append((remote_address, request_type, requested_resource))
        spamming_ip.setdefault(remote_address, 0)
        spamming_ip[remote_address] += 1

print(result, '\n', max(spamming_ip))
