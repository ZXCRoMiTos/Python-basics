import json


def cleaning(name_or_hobby):
    return name_or_hobby.strip()


result = {}

with open('users.csv', 'r', encoding='utf-8') as file_1:
    with open('hobby.csv', 'r', encoding='utf-8') as file_2:
        for hobbies, user in zip(file_2, file_1):
            result[cleaning(user)] = cleaning(hobbies)
        for _ in file_2:
            exit(1)
        for user in file_1:
            result[cleaning(user)] = None

with open('result.csv', 'w', encoding='utf-8') as f:
    json.dump(result, f)
