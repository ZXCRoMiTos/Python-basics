import sys


def show_sale(argv):
    pos_1, pos_2 = 0, 0
    if len(argv) == 3:
        pos_1 = int(argv[1])
        pos_2 = int(argv[2])
    if pos_1 == 0 or pos_2 == 0:
        with open('bakery.csv', 'r', encoding='utf-8') as f:
            return f.read()
    else:
        with open('bakery.csv', 'r', encoding='utf-8') as f:
            count = 1
            result = ''
            for line in f:
                if count >= pos_1:
                    if count <= pos_2:
                        result += line
                count += 1
        return result


some_input = sys.argv
print(show_sale(some_input))
