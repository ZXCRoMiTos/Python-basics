def type_logger(func):
    def wrapper(arg):
        res_type = type(arg)

        return f'{func.__name__}({arg}: {res_type})'

    return wrapper


@type_logger
def calc_cube(x):
    return x ** 3


if __name__ == '__main__':
    print(calc_cube(5))
