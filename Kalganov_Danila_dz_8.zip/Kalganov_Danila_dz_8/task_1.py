import re


def email_parse(email):
    email_pattern = re.compile(r'(?P<username>\w+)@(?P<domain_top>\w+)\.(?P<domain_down>\w+)')
    result = email_pattern.search(email)
    if result:
        return result.groupdict()
    else:
        raise ValueError(email)


if __name__ == '__main__':
    print(email_parse('someone@geekbrains.ru'))
