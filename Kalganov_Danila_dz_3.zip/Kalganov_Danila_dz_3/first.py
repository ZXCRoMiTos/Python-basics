def first_word(word):
    return word[:1].istitle()


def num_translate(word):
    if word.upper() == "ZERO":
        if first_word(word):
            print(f"{word} = ноль")
        else:
            print(f"{word} = ноль")
    elif word.upper() == "ONE":
        if first_word(word):
            print(f"{word} = Один")
        else:
            print(f"{word} = один")
    elif word.upper() == "TWO":
        if first_word(word):
            print(f"{word} = Два")
        else:
            print(f"{word} = два")
    elif word.upper() == "THREE":
        if first_word(word):
            print(f"{word} = Три")
        else:
            print(f"{word} = три")
    elif word.upper() == "FOURTH":
        if first_word(word):
            print(f"{word} = Четыре")
        else:
            print(f"{word} = четыре")
    elif word.upper() == "FIVE":
        if first_word(word):
            print(f"{word} = Пять")
        else:
            print(f"{word} = пять")
    elif word.upper() == "SIX":
        if first_word(word):
            print(f"{word} = Шесть")
        else:
            print(f"{word} = шесть")
    elif word.upper() == "SEVEN":
        if first_word(word):
            print(f"{word} = Семь")
        else:
            print(f"{word} = семь")
    elif word.upper() == "EIGHT":
        if first_word(word):
            print(f"{word} = Восемь")
        else:
            print(f"{word} = восемь")
    elif word.upper() == "NINE":
        if first_word(word):
            print(f"{word} = Девять")
        else:
            print(f"{word} = девять")
    elif word.upper() == "TEN":
        if first_word(word):
            print(f"{word} = Десять")
        else:
            print(f"{word} = десять")
    else:
        print("None")


input_word = input("Введите число на английском от 0 до 10: ")
num_translate(input_word)
