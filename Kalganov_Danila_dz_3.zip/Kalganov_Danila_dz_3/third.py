import random


def get_jokes(num):
    res = []
    for idx in range(num):
        res.append(f"{random.choice(nouns)} {random.choice(adverbs)} {random.choice(adjectives)}")
    return res


nouns = ["автомобиль", "лес", "огонь", "город", "дом"]
adverbs = ["сегодня", "вчера", "завтра", "позавчера", "ночью"]
adjectives = ["веселый", "яркий", "зеленый", "утопичный", "мягкий"]

print(get_jokes(2))
