class Car:
    is_police = False

    def __init__(self, speed, color, name):
        self.speed = speed
        self.color = color
        self.name = name

    def go(self):
        if self.speed != 0:
            print('Машина поехала.')

    def stop(self):
        if self.speed == 0:
            print('Машина остановилась.')

    def turn(self, direction=None):
        if direction is not None:
            print(f'Машина повернула {direction}')

    def show_speed(self):
        print(self.speed)


class TownCar(Car):
    def show_speed(self, speed_limit=60):
        super().show_speed()
        if self.speed > speed_limit:
            print('Превышение скорости!')


class WorkCar(Car):
    def show_speed(self, speed_limit=40):
        super().show_speed()
        if self.speed > speed_limit:
            print('Превышение скорости!')


class SportCar(Car):
    pass


class PoliceCar(Car):
    is_police = True


if __name__ == '__main__':
    a = TownCar(80, 'red', 'Baby')
    a.show_speed()
    a.turn('налево')
    b = WorkCar(60, 'blue', 'little')
    b.show_speed()
    b.go()
    c = PoliceCar(60, 'blue', 'Mercedes')
    print(c.is_police)
