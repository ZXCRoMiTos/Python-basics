class Road:
    def __init__(self, length, width):
        self._length = length
        self._width = width

    def get_weight(self, depth, gravity):
        return self._width * self._length * depth * gravity


if __name__ == '__main__':
    a = Road(100, 20)
    print(a.get_weight(5, 1.5))
