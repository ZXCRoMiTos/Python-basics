class TrafficLight:
    color = {
        'red': 7,
        'yellow': 2,
        'green': 5
    }

    def __init__(self, color='red'):
        self.__color = color

    def switch_color(self):
        if self.__color == 'red':
            self.__color = 'yellow'
        elif self.__color == 'yellow':
            self.__color = 'green'
        else:
            self.__color = 'red'

    def show_color(self):
        print(self.__color)

    def running(self):
        for _ in range(3):
            for _ in range(self.color[self.__color]):
                self.show_color()
            self.switch_color()


if __name__ == '__main__':
    a = TrafficLight('yellow')
    a.switch_color()
    a.running()
