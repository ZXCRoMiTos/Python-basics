from requests import get
from datetime import date


def currency_rates(currency):
    currency = currency.upper()
    response = get('http://www.cbr.ru/scripts/XML_daily.asp')
    content = response.content.decode(encoding=response.encoding)
    if content.find(currency) > 0:
        date_in_file = content[content.find('Date=') + 6: content.find('Date=') + 16].split('.')
        date_in_file.reverse()
        date_in_file = date(int(date_in_file[0]), int(date_in_file[1]), int(date_in_file[2]))
        box = content[content.find(currency):]
        idx = box.find('<Value>')
        left_border = idx + 7
        right_border = idx + 14
        result = float(box[left_border:right_border].replace(',', '.'))
        return result, date_in_file


if __name__ == '__main__':
    print(currency_rates('usd'))
