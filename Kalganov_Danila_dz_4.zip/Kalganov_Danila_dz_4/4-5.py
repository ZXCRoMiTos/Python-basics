import utils
import sys

some_currency = str(sys.argv[1])

print(utils.currency_rates(some_currency))
