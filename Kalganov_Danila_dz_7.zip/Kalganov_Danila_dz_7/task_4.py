import os


def get_key(size):
    num_digits = 1
    while True:
        if size // 10:
            num_digits += 1
        else:
            break
        size //= 10

    return 10 ** num_digits


def size_file_in_dir(root_path):
    result = {}
    for root, _, files in os.walk(root_path):
        for file in files:
            size = os.stat(os.path.join(root, file)).st_size
            key = get_key(size)
            if key in result:
                result[key] += 1
            else:
                result[key] = 1

    return result


print(size_file_in_dir("./"))
