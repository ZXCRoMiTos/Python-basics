import os


def create_project(main_dir, *argv):
   lost_dirs = argv
   if not os.path.exists(main_dir):
      for dir in lost_dirs:
         dir_path = os.path.join(main_dir, dir)
         if not os.path.exists(dir_path):
            os.makedirs(dir_path)
   else:
      print('Данная папкая уже существует')


create_project('дфыафыа1', 'kek', 'lol', 'src')
